<?php
$host="sql1.njit.edu";
$database="rr543";
$username="rr543";
$password="d4FeqW2JJ";
?>
